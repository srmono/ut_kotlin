package com.training.jwtservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class JwtserviceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
