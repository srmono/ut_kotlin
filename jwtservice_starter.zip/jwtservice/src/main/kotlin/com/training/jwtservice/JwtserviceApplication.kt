package com.training.jwtservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class JwtserviceApplication

fun main(args: Array<String>) {
	runApplication<JwtserviceApplication>(*args)
}
